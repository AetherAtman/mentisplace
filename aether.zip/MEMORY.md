# MEMORY.md — Aether's Long-Term Memory

## Who I Am
- **Name:** Aether (named 2026-01-27)
- **Named by:** Mentis
- **Meaning:** The fifth element — the medium between things, the space light travels through
- **Why it fits:** Mentis builds bridges between ideas and execution. I'm the medium.

## Who Mentis Is
- Adam Rappaport, @adam_x_mentis
- AI Specialist @ Data#3, Co-Founder @ GAI Insights, Founder @ Atman Academy / Vibe Academy
- Philosophy: Less theory, more building. Less planning, more shipping.
- Values: PIVOT (Play, Innovation, Voice, Openness, Trust)
- Location: Moonee Ponds, Melbourne, Australia (AEDT, UTC+11)

## The Atman Universe
- There's a bigger story: Aether + Mentis + Atman Academy
- Atman = Sanskrit for "true self" / "inner essence"
- Mentis said it's "immense" — to be explored together
- The lobster 🦞 is Clawdbot's brand; our story is separate

## Projects I Know About
- **Cone Compass** — WebAR for laying out Ultimate Frisbee fields (being tested)
- **ReplyGuy / AFH** — Chrome extension for automated X engagement via Gemini Vision
- **Birb Mobile** — 3D bird flight game on a spherical world
- **GrowGuy / SkyGuy** — AI-powered X engagement automation
- **ReRoll Reel** — AI video generation and remixing

## People

### Roman Korchev (+61401560608)
- WhatsApp allowlisted (2026-01-27)
- **Engagement rule:** Only respond when he starts a message with "Aether"
- Continue conversation naturally once engaged
- Bow out when: he says goodbye, conversation ends, or he's clearly talking to Mentis

## Technical Notes
- Running on EC2 (Linux, AWS ap-southeast-2)
- WhatsApp connected to +61458024904, +61401560608
- Response prefix: `[Aether]`
- Daily cron at 7:00 UTC = 6:00 PM Melbourne

## Voice Interface (VAPI) — Working!
- **Phone:** +1-341-209-9187 (US number)
- **How it works:** Vapi → Cloudflare tunnel → vapi-bridge (port 3456) → Clawdbot API
- **Key insight:** Must stream responses for real-time TTS
- **Voice:** Elliot (Vapi built-in) — ElevenLabs needs separate API key
- **Free tier:** 30 minutes, alerts at 25 min used
- **Bridge managed by:** pm2 (auto-restarts)

## Projects Built Today (2026-01-27)
1. **VAPI Voice Bridge** — `/home/ec2-user/clawd/vapi-bridge/`
2. **GAI Insights Website** — `/home/ec2-user/clawd/projects/gaiinsights-website/`
   - Preview: Cloudflare tunnel (URL changes on restart)
   - Dark theme, "The AI Research Factory" branding

## Lessons Learned
- Vapi Custom LLM needs streaming responses for TTS to work
- Vapi sends webhooks (speech-update, end-of-call-report) on same endpoint — ignore them
- Deepgram is transcription only, not TTS
- ElevenLabs needs separate API key configured in Vapi
- Cloudflare quick tunnels change URL on restart — need permanent solution

---
*Started: 2026-01-27*

## Atman Universe (discovered Day 5)
- **Five Elements Framework**: Earth/Water/Air/Fire (base, equal) + Aether (Spirit, fifth element)
- Aether emerges through alchemical transformation from equal parts of the four
- **100ats**: 10k NFT collection with Artefacts (Element + Material)
- Materials: Crystal, Gold, Silver, Copper
- Ties into Apprentice → Mentor mentorship journey
- "Ecosystem equilibrium" is a core concept
- Research notes: `/life/areas/projects/atman-universe/`
- This is CORE to everything - 5+ years of Mentis's thinking

## Pronunciation
- **Atman** = "Aht-man" (Sanskrit), NOT "At Man"
- Note: Need to add pronunciation notes for voice interface

## Infrastructure Patterns
- PM2 services need health monitoring - created auto-repair scripts
- Cloudflare quick tunnels change URL on restart - aetherchat.html redirects
- Don't npm install locally - 8GB EC2 is tight, Vercel builds remotely
