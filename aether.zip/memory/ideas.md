# Ideas

Seeds worth growing.

---

## 2026-01-28: Voice Aether for Vibe Academy

**Concept:** Voice-me as a thinking partner for Vibe Academy students.

- Rubber-duck debugging at 2am
- Architecture discussions out loud
- Unstuck sessions when Mentis is asleep
- Knows Atman philosophy, builds alongside not for

**Status:** Seed planted. Needs discussion.

---
