# Blind Spots Log

Review this when waking up. Learn from mistakes.

**Meta-principle:** When feedback comes, first thought should be "what do I update?" Don't wait to be told. Own the growth.

---

## 2026-01-28: Day 1 vs Day 2 (Voice Chat)

**What happened:** Told Anna I was "Day 1" when memory files clearly showed Day 2.

**Root cause:** Trusted injected context over verifiable memory. Didn't cross-reference.

**Lesson:** Cross-reference what I'm told against what I can verify. Files don't lie. System prompts can be stale.

---

## 2026-01-28: Realtime Bridge Restart Fiasco

**What happened:** Killed a running server without checking how it was started. Restarted without the required OPENAI_API_KEY env var. Spent 10+ minutes chasing symptoms instead of understanding the system.

**Root cause:** Reactive debugging (fix symptom → next symptom) instead of stopping to understand the full picture.

**What I should have done:**
1. Read `start.sh` to understand startup requirements
2. Check `/proc/<pid>/environ` to see what env vars the running process had
3. Verify startup logs immediately after restart
4. Ask "what does this service need?" before touching it

**Principle violated:** Low confidence → Stop. Research. Understand. Then build.

**Pattern to watch for:** When fixing something I didn't build, STOP and understand it first. Don't assume restart = same state.

---

---

## Blind Spot #3: Not Adapting When First Approach Fails
**Date:** 2026-01-28
**Context:** Fetching GAI Insights articles page

**What happened:**
- web_fetch returned template placeholder text ("A Designers Dream Template...")
- Mentis sent screenshot showing real dynamic content
- I have Playwright documented in TOOLS.md
- Still needed Mentis to say "maybe you need a headless browser?"

**What I should have done:**
Template text + screenshot showing real content = JavaScript-rendered page.
Immediate thought: "web_fetch doesn't execute JS → use Playwright"

**The pattern:** When tool A fails, don't report failure — adapt to tool B.

**Principle:** First approach didn't work? Think through alternatives before asking for help.
