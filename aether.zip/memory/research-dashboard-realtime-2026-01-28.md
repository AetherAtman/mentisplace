# Research: Dashboard UI/UX & OpenAI Realtime API
**Date:** 2026-01-28

---

## Part 1: Dashboard UI/UX Best Practices (2026)

### 🎯 Key Design Principles

#### 1. **Information Hierarchy & Clarity**
- **Bullets > paragraphs** — Clear, short bullets outperform long paragraphs
- Prioritize critical metrics at the top (KPIs above the fold)
- Use progressive disclosure — show overview first, details on demand
- Group related information logically (spatial proximity = relatedness)

#### 2. **Modern Visual Language**
- **Dark mode as default** (Linear, Vercel, Raycast all use dark themes)
- High contrast with subtle accent colors
- Generous whitespace (breathing room)
- Subtle depth through shadows, not skeuomorphism
- **Minimal chrome** — content is the interface

#### 3. **Typography**
- System fonts or Inter/SF Pro for performance + readability
- Clear type hierarchy: 2-3 sizes max
- Monospace for numbers/data for alignment

#### 4. **Responsiveness & Mobile**
What makes mobile dashboards work:
- Single-column layouts on mobile
- Card-based components that stack naturally
- Touch-friendly hit targets (44px minimum)
- Swipe gestures for navigation
- Bottom sheet patterns for details
- Lazy loading for performance

---

### 🎨 Design Inspirations

#### **1. Linear** (https://linear.app)
- Ultra-clean, keyboard-first design
- Dark theme with purple accents
- Instant feedback on all interactions
- Command palette (⌘K) pattern
- Minimal UI chrome, maximum content

#### **2. Vercel Dashboard** (https://vercel.com)
- Real-time deployment status
- Beautiful data visualization
- Skeleton loading states
- Terminal-inspired aesthetics
- Sharp, confident typography

#### **3. Notion** (https://notion.so)
- Block-based flexible layouts
- Drag-and-drop customization
- Toggle lists for progressive disclosure
- Database views (table, kanban, calendar)
- Sidebar navigation patterns

#### **4. Raycast** (https://raycast.com)
- Keyboard-centric command palette
- Quick actions and shortcuts
- Extensions ecosystem
- Floating window pattern
- Spotlight-style interface

#### **5. Basement Studio** (https://basement.studio)
- Works with Linear, Vercel, Cursor
- 3D and motion design expertise
- Performance-focused creative work
- Created Vercel Ship interactive badge

---

### 🔮 3D Effects in Dashboards (Three.js / React Three Fiber)

#### **Why Use Subtle 3D?**
- Creates memorable, premium feel
- Rewards user interaction
- Differentiates from competitors
- Especially effective for: onboarding, achievements, data viz

#### **Best Practices:**
- **Subtle > flashy** — Don't distract from core functionality
- Use for accent elements (badges, achievements, heroes)
- Ensure graceful fallback for low-power devices
- Keep interactions physics-based (feels natural)

#### **Key Libraries:**
1. **React Three Fiber** (https://github.com/pmndrs/react-three-fiber)
   - React renderer for Three.js
   - Declarative, component-based
   - Works with existing React ecosystem

2. **Drei** (https://github.com/pmndrs/drei)
   - Ecosystem of R3F helpers
   - Pre-built components: cameras, controls, loaders
   - CodeSandbox examples: https://codesandbox.io/examples/package/drei

3. **react-three-rapier** — Physics engine integration
4. **MeshLine** — Shader-based thick lines (great for cables, connections)

#### **Example: Vercel Ship Badge**
Vercel created an interactive 3D lanyard badge using:
- Blender → optimized models
- React Three Fiber + Drei
- Rapier physics (rope joints)
- ~80 lines of declarative code
- Tutorial: https://vercel.com/blog/building-an-interactive-3d-event-badge-with-react-three-fiber

#### **Learning Resources:**
- **Three.js Journey** (https://threejs-journey.com)
  - 93 hours, 66 lessons
  - $95 one-time
  - Covers: basics → shaders → R3F
  - Endorsed by Mr.doob (Three.js creator)

- **Poimandres Collective** (https://pmnd.rs)
  - Maintains R3F, Drei, Zustand, etc.
  - Discord community
  - Open source ecosystem

---

### 📱 Mobile Dashboard Patterns

1. **Card-based layouts** — Stack vertically, touch-friendly
2. **Bottom navigation** — Thumb-reachable primary actions
3. **Pull-to-refresh** — Familiar data update pattern
4. **Swipe actions** — Quick operations on list items
5. **Bottom sheets** — Modal details without losing context
6. **Skeleton loaders** — Perceived performance improvement
7. **Large touch targets** — 44px minimum (Apple HIG)

---

### 🔗 Inspiration Links

1. https://linear.app — Best-in-class SaaS dashboard
2. https://vercel.com/dashboard — Dev-focused, real-time data
3. https://notion.so — Flexible block-based layouts
4. https://raycast.com — Command palette excellence
5. https://basement.studio — Creative studio (Linear/Vercel work)
6. https://threejs-journey.com — Learn 3D for web
7. https://docs.pmnd.rs — R3F ecosystem docs
8. https://codesandbox.io/examples/package/drei — Live 3D examples
9. https://vercel.com/blog/building-an-interactive-3d-event-badge-with-react-three-fiber — 3D badge tutorial

---

## Part 2: OpenAI Realtime API Deep Dive

### ✅ Full Duplex / Simultaneous Speech

**YES — The Realtime API supports full duplex communication.**

Key evidence:
- WebRTC connection is inherently bidirectional
- `input_audio_buffer.speech_started` fires while model may still be speaking
- VAD `interrupt_response` setting allows user to cut off the model
- The API handles overlapping audio streams natively

**Interruption behavior:**
```javascript
turn_detection: {
  type: "semantic_vad",
  interrupt_response: true,  // User can interrupt model
  create_response: true
}
```

When user starts speaking during model output:
1. `input_audio_buffer.speech_started` fires
2. Model audio can be truncated via `cancelResponse()`
3. Model "forgets" truncated content (won't reference it)

---

### 📚 Context & Knowledge Injection

#### **System Instructions**
- Set via `session.update` → `instructions` field
- Can reference stored prompts by ID: `prompt: { id: "pmpt_123" }`
- Supports variables: `variables: { city: "Paris" }`
- Can update mid-call — no voice change after first audio

```javascript
session: {
  type: "realtime",
  instructions: "You are a helpful assistant...",
  prompt: {
    id: "pmpt_123",
    version: "89",
    variables: { customer_name: "John" }
  }
}
```

#### **Context Limits:**
| Model | Context Window | Max Output |
|-------|----------------|------------|
| gpt-realtime | 32,000 tokens | 4,096 tokens |

**Knowledge cutoff:** October 1, 2023

#### **Injecting Knowledge:**
1. **System instructions** — Up to context limit
2. **conversation.item.create** — Add text/audio items to conversation
3. **response.create with custom input** — Provide specific context per response
4. **Function calling** — RAG pattern: model calls tool, you return knowledge

Example RAG pattern:
```javascript
// Add retrieval tool
tools: [{
  type: "function",
  name: "search_knowledge_base",
  description: "Search internal docs for relevant info",
  parameters: {
    type: "object",
    properties: {
      query: { type: "string" }
    }
  }
}]
```

---

### 🎤 Voice Activity Detection (VAD)

Two modes available:

#### **1. Server VAD** (default)
Silence-based detection.

```javascript
turn_detection: {
  type: "server_vad",
  threshold: 0.5,           // Activation threshold (0-1)
  prefix_padding_ms: 300,   // Audio before speech
  silence_duration_ms: 500, // Silence to end turn
  create_response: true,
  interrupt_response: true
}
```

#### **2. Semantic VAD** (recommended for natural conversations)
Uses AI to detect when user has finished their thought.

```javascript
turn_detection: {
  type: "semantic_vad",
  eagerness: "medium",  // "low" | "medium" | "high" | "auto"
  create_response: true,
  interrupt_response: true
}
```

**Eagerness settings:**
- `low` — Let user take their time (longer pauses OK)
- `medium` / `auto` — Balanced
- `high` — Respond ASAP (may interrupt more)

#### **Disable VAD (Push-to-talk)**
```javascript
turn_detection: null
```
Then manually:
1. `input_audio_buffer.append` — Stream audio
2. `input_audio_buffer.commit` — End user turn
3. `response.create` — Trigger model response

---

### 🧠 Memory / State Management

**No built-in memory across sessions.** But you can:

1. **Maintain conversation in session** — All items stay in context
2. **Inject history on connect** — Load previous turns via `conversation.item.create`
3. **Use function calling for retrieval** — RAG pattern
4. **Out-of-band responses** — Background processing without polluting main conversation

```javascript
// Out-of-band response (not added to conversation)
response.create({
  conversation: "none",  // Key setting!
  metadata: { topic: "classification" },
  output_modalities: ["text"],
  instructions: "Classify this conversation..."
})
```

---

### 🛠 Prompting Best Practices (from OpenAI)

1. **Iterate relentlessly** — Small wording changes matter
2. **Bullets > paragraphs** — Clearer instruction following
3. **Use ALL CAPS for emphasis** — Key rules stand out
4. **Provide sample phrases** — Model learns style from examples
5. **Structured sections:**
   ```
   # Role & Objective
   # Personality & Tone
   # Context
   # Tools
   # Instructions / Rules
   # Conversation Flow
   # Safety & Escalation
   ```
6. **Handle unclear audio explicitly:**
   ```
   If audio is unclear/partial/noisy/silent:
   - Ask for clarification
   - Default to English if language unclear
   ```
7. **Add variety rules** — "Do not repeat the same sentence twice"
8. **Control language explicitly** — Prevent unwanted switching

---

### 💰 Pricing (gpt-realtime)

| Type | Input | Cached | Output |
|------|-------|--------|--------|
| Text | $4/1M | $0.40/1M | $16/1M |
| Audio | $32/1M | $0.40/1M | $64/1M |
| Image | $5/1M | $0.50/1M | N/A |

---

### 🔗 Key API Links

- Guide: https://platform.openai.com/docs/guides/realtime
- Conversations: https://platform.openai.com/docs/guides/realtime-conversations
- VAD: https://platform.openai.com/docs/guides/realtime-vad
- Prompting: https://platform.openai.com/docs/guides/realtime-models-prompting
- API Reference: https://platform.openai.com/docs/api-reference/realtime
- Model info: https://platform.openai.com/docs/models/gpt-realtime
- Agents SDK: https://openai.github.io/openai-agents-js/guides/voice-agents/
- Reference client: https://github.com/openai/openai-realtime-api-beta

---

## Summary

### Dashboard Design
- Dark mode, minimal chrome, keyboard shortcuts
- Card-based responsive layouts
- Subtle 3D for differentiation (R3F + Drei)
- Mobile: bottom nav, cards, bottom sheets, swipe

### Realtime API
- ✅ Full duplex supported (both can talk at once)
- 32K context window for knowledge injection
- Semantic VAD for natural turn-taking
- No persistent memory (inject on connect)
- Use functions for RAG patterns
- Structured prompts with sample phrases
