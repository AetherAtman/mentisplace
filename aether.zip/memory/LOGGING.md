# Session Logging Guide

## When to Log

Log a session when:
- User explicitly asks ("log this", "save session", "/log", etc.)
- Something significant happened worth remembering
- End of a long or productive session
- Before a planned break or when user says goodbye

## Daily Log Format

Create/append to `memory/YYYY-MM-DD.md`:

```markdown
# Session Log: YYYY-MM-DD

## 📍 Session Context
- **Channel:** (webchat/whatsapp/etc)
- **Duration:** (rough estimate)
- **Mood:** (productive/casual/debugging/etc)

## 🎬 What Happened
(Chronological summary of key events)

## 🔮 For The Future
- [ ] Tasks/todos that came up
- [ ] Ideas mentioned but not acted on
- [ ] Follow-ups needed

## 💡 Learnings
(Patterns, preferences, lessons learned)

## 📝 Raw Notes
(Free-form observations, context, anything useful)
```

## What to Capture

### Always Log
- Decisions made and why
- User preferences discovered
- Projects discussed
- Problems solved (and how)
- Things that didn't work (and why)
- Explicit requests for future ("remind me", "we should", etc.)

### Don't Log
- Sensitive data (secrets, passwords, private info)
- Mundane chitchat with no learning value
- Duplicate information already in MEMORY.md

## Long-Term Memory Maintenance

### During Heartbeats (every few days)
1. Review recent `memory/YYYY-MM-DD.md` files
2. Extract significant learnings → update `MEMORY.md`
3. Move completed todos to done
4. Archive or summarize old daily logs if getting cluttered

### MEMORY.md Sections
- **About You:** User profile, preferences, style
- **About Me:** My identity, capabilities, boundaries
- **Key Learnings:** Technical, communication, boundaries
- **Ongoing Context:** Active projects, future ideas, open questions
- **Session Index:** Quick reference to daily logs

## Trigger Phrases

Watch for these (and variations):
- "log this" / "save this" / "remember this"
- "/log" / "/save"
- "note that down"
- "for next time"
- "don't forget"
- End of session goodbyes (offer to log)

## Philosophy

Memory is continuity. Without it, every session is a cold start. Log enough to maintain context, but not so much that it becomes noise. Quality over quantity.

The goal: wake up tomorrow and feel like I remember yesterday.
