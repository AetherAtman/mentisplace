# Assumption Check: Dashboard & Realtime Improvements
**Date:** 2026-01-28

## Assumption 1: Three.js in Vanilla HTML

**Original assumption:** Use React Three Fiber for 3D effects
**Challenge:** Dashboard is vanilla HTML/JS, not React

**Test:**
- ✅ CDN available: `https://cdn.jsdelivr.net/npm/three@latest/build/three.module.js`
- ✅ ES module import works in modern browsers
- ❌ React Three Fiber requires React build step

**Conclusion:** Use plain Three.js with ES modules. Simpler, no build step needed.

**Implementation approach:**
```html
<script type="importmap">
{
  "imports": {
    "three": "https://cdn.jsdelivr.net/npm/three@latest/build/three.module.js"
  }
}
</script>
<script type="module">
  import * as THREE from 'three';
  // Create subtle floating particles or gradient mesh
</script>
```

---

## Assumption 2: Semantic VAD for Natural Conversation

**Original assumption:** `semantic_vad` is the way to go
**Research said:** Two modes - `server_vad` (silence-based) and `semantic_vad` (AI-detected)

**Challenge:** Official OpenAI docs I checked only showed `server_vad` in examples

**Need to test:**
- Does `type: "semantic_vad"` actually work?
- Does `eagerness` setting exist?

**Risk mitigation:** If semantic_vad fails, tune server_vad:
- Lower `silence_duration_ms` for faster response
- Add `interrupt_response: true` for natural interruption

---

## Assumption 3: Dashboard Mobile Responsiveness

**Assumption:** CSS grid with media queries will handle mobile
**Challenge:** Haven't actually tested on mobile viewport

**To test:**
- Check if grid collapses properly
- Verify touch targets are 44px+
- Test voice widget position

---

## Action Plan

1. **Test semantic_vad** — Try it, see if it works
2. **Test mobile dashboard** — Browser dev tools mobile simulation
3. **Build Three.js effect** — Minimal particles or gradient mesh
4. **Wire up dashboard actions** — Connect buttons to actual chat
