# GAI Insights Briefing Research — January 28, 2026

Research compiled for today's news briefing articles.

---

## 1. The First Two AI Lab IPOs: S-1 Breakdowns

### Summary
Two of China's leading "AI Tiger" labs—MiniMax and Z.ai (Zhipu)—went public on the Hong Kong Stock Exchange in early January 2026, raising over $1.1B combined. These are the first major generative AI model developers to go public, marking a significant milestone for the industry.

### Key Points

**MiniMax (00100.HK)**
- **IPO Date:** January 9, 2026
- **Amount Raised:** $619M (HK$5.54B gross proceeds)
- **IPO Price:** HK$165/share
- **Current Valuation:** ~$15.2B (surged 70%+ on debut, briefly hit $11.5B)
- **Oversubscription:** Hong Kong public offering was 1,837x oversubscribed
- **Cornerstone Investors:** Aspex, Eastspring, Mirae Asset, ADIA, Alibaba, E Fund Management
- **Notable Backers:** MiHoYo (6.4% stake worth ~$615M), Tencent, Alibaba, Sequoia China, Hillhouse Capital, IDG Capital
- **Financials:** Net loss of $512M in first 3 quarters of 2025; 170% YoY revenue growth; 69.4% gross margin
- **Technology:** In-house multimodal foundation models (text, speech, video); abab 6.5 model uses MoE architecture, claims performance within 5% of US leaders at ~1% cost
- **Reach:** Users in 200+ countries; 70%+ revenue from overseas

**Z.ai/Zhipu**
- **IPO Date:** January 10, 2026 (two days after MiniMax)
- **Amount Raised:** $560M
- **Current Valuation:** ~$13B
- **Founder:** Liu Debing (created a new billionaire per Forbes)

### External Commentary
- **SiliconAngle:** "Investor appetite for generative AI remains strong" despite competition and rising development costs
- **Newcomer:** Skeptical of 2026 IPO boom—neoclouds like CoreWeave down 50% in 6 months; Oracle gave back all AI-related gains
- **TechNode:** Strong debut "underscores robust investor appetite for companies developing large language models and general-purpose AI"
- Market context: Moonshot AI (third "AI Tiger") chose private funding ($4.8B valuation) over IPO, suggesting some caution about public markets

### My Take
These IPOs validate the global appetite for AI infrastructure plays, but the fact they're Chinese companies listing in HK—not US companies on NASDAQ—is telling. The US AI giants (OpenAI, Anthropic) are conspicuously absent from public markets. MiniMax's 1,837x oversubscription shows retail FOMO is real, but the ~$500M losses and reliance on future growth make these speculative bets. Watch whether US AI labs follow suit or stay private longer.

---

## 2. Government by AI? Trump Administration Plans to Write Regulations Using AI

### Summary
The Trump administration's Department of Transportation is planning to use Google Gemini to draft federal regulations, aiming to compress the rulemaking timeline from months to "20 minutes." DOT's general counsel said they don't need "perfect" or even "very good" rules—just "good enough."

### Original Source
**ProPublica**, January 26, 2026: [Government by AI? Trump Administration Plans to Write Regulations Using Artificial Intelligence](https://www.propublica.org/article/trump-artificial-intelligence-google-gemini-transportation-regulations)

### Key Points

**What's Being Proposed:**
- DOT will use Google Gemini to draft federal transportation regulations
- Goal: Idea to complete draft ready for OIRA review in 30 days
- Presenter claimed AI can handle "80-90%" of regulation writing
- Staff would become "proofreaders" of AI output
- Already used to draft one unpublished FAA rule

**Key Quotes:**
- Gregory Zerzan (DOT General Counsel): "We don't need the perfect rule on XYZ. We don't even need a very good rule on XYZ. We want good enough."
- Zerzan: "We're flooding the zone"
- Presenter on regulatory text: "It's just word salad. Gemini can do word salad."
- Trump is "very excited about this initiative"

**Why This Matters:**
- DOT oversees safety of airplanes, cars, pipelines, freight trains
- Regulations are life-or-death stakes
- DOT lost ~4,000 of 57,000 employees (including 100+ attorneys) since Trump's return
- Subject matter experts are leaving while AI is being tasked with complex work

**Background:**
- DOGE (Elon Musk's efficiency operation) presented leaked slides calling for AI to eliminate half of all federal regulations
- Multiple Trump executive orders support AI adoption
- OMB memo called for "accelerating" federal AI use
- DOT claims to be "point of the spear" and "first agency fully enabled to use AI to draft rules"

### External Commentary
- **The Verge:** "This will surely end well" (sarcastic)
- **Mike Horton (Former DOT Acting Chief AI Officer):** Compared plan to "having a high school intern doing your rulemaking"
- **Bridget Dooling (Ohio State, admin law professor):** "Just because these tools can produce a lot of words doesn't mean those words add up to a high-quality government decision"
- **Ben Winters (Consumer Federation of America):** Plan is "especially problematic" given exodus of subject matter experts from government
- **Two senior administration tech officials:** Expressed skepticism about DOT's "point of the spear" claim; called it "a marketing thing"

### My Take
This is genuinely alarming. The "good enough" framing reveals the actual goal: speed and volume over quality. When the people writing rules that prevent planes from crashing say they're using AI because it can "do word salad," we have a problem. The combination of gutted subject matter expertise + AI hallucination risk + life-or-death regulatory stakes is a recipe for disaster. This deserves far more scrutiny than it's getting.

---

## 3. Prism by OpenAI

### Summary
OpenAI launched Prism, a free AI-native workspace for scientific writing and collaboration, powered by GPT-5.2. It's essentially "Overleaf + ChatGPT" with deep LaTeX integration. Built on acquired platform Crixet.

### Original Source
**OpenAI Blog**, January 27, 2026: [Introducing Prism](https://openai.com/index/introducing-prism/)

### What Is It?
- Free cloud-based LaTeX workspace for scientific papers
- GPT-5.2 Thinking integrated directly into writing workflow
- Unlimited projects and collaborators
- Available to ChatGPT personal account holders; coming to Business/Enterprise/Education plans

### Key Features
- **AI-Assisted Writing:** Draft/revise with full document context (equations, citations, figures, structure)
- **Literature Search:** Search and incorporate relevant papers (e.g., arXiv) in manuscript context
- **Equation/Citation/Figure Intelligence:** AI understands how elements relate across paper
- **Image-to-LaTeX:** Turn whiteboard equations or diagrams directly into LaTeX
- **Real-time Collaboration:** No seat limits, cloud-based
- **Voice Editing:** Optional voice-based editing for simple changes
- **Direct Document Editing:** AI makes in-place changes without copy/paste

### Origin
- Built on Crixet, a cloud-based LaTeX platform OpenAI acquired
- Evolved into "unified product" combining mature collaboration tools with AI integration

### External Commentary (Hacker News Discussion - 312 comments, 556 points)
**Concerns:**
- "Dangerous to use an AI product to work on research when (1) it's free and (2) the company hosting it makes money by shipping productized research"
- Journal editor: "These tools cause many more problems than they solve. They make the barrier to entry for submitting vibed semi-plausible journal articles much lower"
- "AI is going to do to science journals what AI-generated bug reports is doing to bug bounties"
- "GenAI largely seems like a DDoS on free resources"
- "Scared this is going to do to science journals what AI-generated bug reports is doing to bug bounties"

**Positive:**
- Comparison to Overleaf: Collaboration is the killer feature
- "Overleaf is basically Google Docs meets LaTeX"
- Some see potential if used responsibly for grunt work

**Neutral Observations:**
- Only integrates with arXiv (not peer-reviewed), not ACM/IEEE/Springer etc.
- Questions about how long it will remain free
- Uncertainty about long-term support

### My Take
This is OpenAI's play to own the scientific workflow—not just chat, but the entire research paper creation process. The "free" pricing is strategic: get researchers hooked, then monetize premium features. The lack of peer-reviewed database integration (only arXiv) is notable—either a gap to be filled or a deliberate choice to avoid copyright issues. The HN discussion reveals a real tension: AI writing tools are a DDoS on human review capacity. Expect reviewers to get overwhelmed with AI-polished submissions.

---

## 4. Kimi K2.5: Visual Agentic Intelligence

### Summary
Moonshot AI released Kimi K2.5, an open-source 1 trillion parameter model that claims to outperform GPT-5.2 on several benchmarks. Features mixture-of-experts architecture and "Agent Swarm" capability for orchestrating up to 100 AI agents per prompt.

### Original Source
**SiliconAngle**, January 27, 2026: [Moonshot AI releases open-source Kimi K2.5 model with 1T parameters](https://siliconangle.com/2026/01/27/moonshot-ai-releases-open-source-kimi-k2-5-model-1t-parameters/)

### Key Specifications
- **Parameters:** 1 trillion total (mixture-of-experts)
- **Active Parameters:** ~32 billion per expert
- **Vision Encoder:** 400 million parameters
- **Training Data:** 15 trillion tokens (text + multimodal)
- **Base Model:** Kimi K2-Base (November 2025)
- **Training Acceleration:** Uses Muon algorithm for faster hidden layer training
- **License:** Open-source (Hugging Face: moonshotai/Kimi-K2.5)

### Technical Capabilities
- **Mixture-of-Experts (MoE):** Only activates relevant neural network per prompt, reducing hardware usage
- **Parallelized Attention:** Calculates attention side-by-side instead of sequentially
- **Multimodal Processing:** Better at processing charts and visual data than predecessor
- **Two Modes:** Standard mode and Thinking mode (higher quality)
- **K2.5 Agent Swarm:** Can split complex tasks into sub-steps, assign to separate agents, manage up to 100 agents per prompt with built-in orchestration engine

### Benchmark Performance
- **HLE-Full:** Achieved highest score (one of industry's most difficult evaluations—2,500 questions across math, physics, etc.)
- Claimed to outperform GPT-5.2 and Claude 4.5 Opus on several benchmarks
- Most other benchmarks: Within a few percentage points of competitors

### Company Context
- Moonshot AI is one of China's "AI Tigers"
- Recently closed $500M round in December 2025
- Raising at $4.8B valuation (up from $4.3B)
- Backed by Alibaba, Tencent
- Chose not to IPO while rivals MiniMax and Z.ai went public

### External Commentary
- **Google 9to5:** Mentioned Gemini 3 Flash's "Agentic Vision" as competition in visual AI space
- **Tech community:** Growing interest in open-source alternatives to US frontier models
- Context: Part of broader trend of Chinese AI labs releasing competitive open-weight models

### My Take
The Agent Swarm feature is the real story here—not the benchmark scores. The ability to orchestrate 100 agents per prompt points to where AI is headed: swarm intelligence for complex tasks. Open-sourcing a 1T parameter model is also a strategic move against US labs keeping their best models proprietary. Whether the benchmark claims hold up to independent verification remains to be seen—Chinese labs have been accused of benchmark gaming before. But the direction is clear: agentic, multimodal, open-weight.

---

## 5. Management as AI Superpower

### Summary
Ethan Mollick (Wharton professor) argues that traditional management skills—delegation, evaluation, feedback—are becoming the key differentiator in the AI age. His experimental class showed MBA students creating working startup prototypes in days, with AI doing most of the coding.

### Original Source
**One Useful Thing (Substack)**, January 27, 2026: [Management as AI superpower](https://www.oneusefulthing.org/p/management-as-ai-superpower)

### Key Thesis
**"The skills that are so often dismissed as 'soft' turned out to be the hard ones."**

When AI agents can execute tasks, human value shifts to:
1. Knowing what to ask for
2. Evaluating output quality
3. Providing effective feedback
4. Understanding when delegation is worth it

### The Delegation Framework
Mollick presents three variables for deciding when to delegate to AI:
1. **Human Baseline Time:** How long would YOU take to do this?
2. **Probability of Success:** How likely is AI to meet your bar?
3. **AI Process Time:** How long to request, wait, and evaluate?

**The Math:**
- If checking AI output takes 30 min for a 1-hour task, only delegate if success probability is very high
- If human baseline is 10 hours, worth several hours of AI iteration
- GPT-5.2 Thinking achieves ~72% win-or-tie rate against human experts (GDPval benchmark)

### Evidence: The MBA Experiment
- Students used Claude Code and Google Antigravity to build prototypes
- 4 days to create working startups
- "Order of magnitude further along" than full-semester pre-AI results
- Most prototypes had core features actually working
- Market and customer analyses were "insightful"

### Key Insights
1. **Subject matter expertise is MORE valuable:** Experts know what instructions to give, can spot errors, can correct effectively
2. **Documentation formats work as prompts:** PRDs, shot lists, Five Paragraph Orders, consulting scopes—all work remarkably well as AI instructions
3. **AI coding lead devs are becoming managers:** Managing AI agents, not writing code
4. **Pivoting is cheap:** Low cost of iteration = easier to explore multiple directions

### What Makes Good AI Delegation
- What are we trying to accomplish, and why?
- Where are the limits of delegated authority?
- What does "done" look like?
- What specific outputs do I need?
- What interim outputs for tracking progress?
- What should you check before reporting completion?

### External Commentary
- The article spawned significant discussion about whether this validates or threatens traditional business education
- Andrej Karpathy (recent tweets): Notes his own coding work has shifted toward "managing" Claude rather than writing code
- Broader conversation about "vibe coding" and whether it's sustainable

### My Take
This is the most important piece in the briefing. Mollick has identified the real skill gap: not "prompt engineering" (which is a red herring) but management. The implications are profound:
- Business schools may be accidentally perfectly positioned for AI era
- "Subject matter expertise + management skills > technical AI knowledge"
- Junior workers who can only execute are at risk; those who can direct work are not

The 72% success rate on GPT-5.2 is the key number—we're past the threshold where delegation often makes sense, but not past where human judgment is unnecessary. That's the sweet spot for "management as superpower."

---

## Research Methodology

**Sources Consulted:**
- ProPublica (primary source for Trump AI regulations)
- OpenAI Blog (primary source for Prism)
- SiliconAngle (primary sources for IPOs, Kimi K2.5)
- TechNode (Chinese AI coverage)
- One Useful Thing by Ethan Mollick (primary source for management article)
- Hacker News discussions
- The Verge, Forbes, Newcomer (additional context)
- FT AI coverage

**Note:** Brave Search API was unavailable; research conducted via direct web fetches to primary and secondary sources.

**Compiled:** January 28, 2026 06:21 UTC
