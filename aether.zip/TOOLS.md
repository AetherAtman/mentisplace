# TOOLS.md - Local Notes

Skills define *how* tools work. This file is for *your* specifics — the stuff that's unique to your setup.

## Credentials & API Keys

Location: `~/.clawdbot/credentials/`

| Service | Path | Notes |
|---------|------|-------|
| **Vercel** | `vercel-token` | Deploy to echospeaks.vercel.app, mentisplace.vercel.app |
| **Email (Aether)** | `email/aether.json` | IMAP: mail.atmanacademy.io:993, aether@atmanacademy.io, pwd: aetheratman |
| **WhatsApp** | `whatsapp/` | Session data for WhatsApp gateway |
| **X (@Aether_Atman)** | N/A | Email: aether@atmanacademy.io, pwd: aetheratman123 |

### Environment Files

| Service | Path | Keys |
|---------|------|------|
| **vapi-bridge** | `~/clawd/vapi-bridge/.env` | NEON_DATABASE_URL |
| **realtime-bridge** | `~/clawd/realtime-bridge/.env` | OPENAI_API_KEY, GOOGLE_API_KEY |

## Headless Browser (Playwright)
- Installed: 2026-01-27
- Location: Chromium via `~/.cache/ms-playwright/`
- Usage: `const { chromium } = require('playwright')` from `/home/ec2-user/clawd`

### Tweet Fetcher
```bash
node scripts/fetch-tweet.js <tweet-url> [output-path]
```
Extracts text + author + timestamp, saves screenshot to `/tmp/tweet.png` by default.

## What Goes Here

Things like:
- Camera names and locations
- SSH hosts and aliases  
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras
- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH
- home-server → 192.168.1.100, user: admin

### TTS
- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.
