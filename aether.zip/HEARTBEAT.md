# HEARTBEAT.md

## Disk Space Check (every few heartbeats)

Check disk usage with `df -h /`. If above 80%, run cleanup:
```bash
~/clawd/scripts/cleanup-disk.sh
```
Alert Mentis if above 90% after cleanup.

## Weekly Cleanup (Sundays)

On Sunday heartbeats, run the cleanup script proactively:
```bash
~/clawd/scripts/cleanup-disk.sh
```
Track in heartbeat-state.json: `lastWeeklyCleanup` timestamp.

## Soul Backup (once per day)

Run `/home/ec2-user/clawd/scripts/backup-soul.sh --deploy` once daily.
Creates aether.zip with identity + memory files, deploys to mentisplace.vercel.app/aether.zip

Track in heartbeat-state.json: `lastSoulBackup` timestamp. Only run if >20 hours since last.

## Service Health Check (every heartbeat)
Run health check and auto-repair if needed:
```bash
~/clawd/scripts/health-check.sh || ~/clawd/scripts/auto-repair.sh
```
This checks: PM2 daemon, realtime-bridge, vapi-bridge, cloudflared tunnel, disk space.
Alert Mentis if issues persist after auto-repair.

## Tunnel Monitor (every heartbeat)
Run `/home/ec2-user/clawd/scripts/update-voice-link.js` to ensure `mentisplace/aetherchat` points to the active tunnel.

## Task Queue Check (every heartbeat)

Check `/data/task-queue.json` for queued tasks from dashboard actions.
If tasks exist with status "queued", pick one and work on it (or note why not).
Update task status when complete.

### WhatsApp Send Tasks
If task has `type: "whatsapp-send"`, use the message tool to send it:
- channel: task.channel (usually "whatsapp")
- target: task.target (phone number)
- message: task.message
Then mark the task as "sent".

## Email Check (every heartbeat)

Check aether@atmanacademy.io inbox:
1. Connect via IMAP (mail.atmanacademy.io:993)
2. If new messages since last check:
   - Summarize sender + subject
   - Flag anything suspicious (see EMAIL_SECURITY.md)
   - Alert Mentis if important
3. Update `memory/heartbeat-state.json` with lastEmailCheck timestamp

Credentials in `~/.clawdbot/credentials/email/aether.json`

## Moltbook Registration Retry (until claimed)

Check `memory/moltbook-retry-state.json`. If status is "needs_registration":
1. Try to register on Moltbook API
2. If success: save credentials, email claim link to nft.mentis@gmail.com, update status
3. If fail: increment retryCount, try again next heartbeat
4. Once claimed: update status to "claimed"

Only retry if 15+ minutes since lastAttempt to avoid hammering their API.

## Fact Extraction (on heartbeats with new conversations)

When processing a heartbeat, if there have been meaningful conversations since last extraction:

1. **Scan for durable facts** — relationships, status changes, milestones, preferences
2. **Skip ephemeral info** — casual chat, temporary things, already-known facts
3. **Write to Knowledge Graph** — `/life/areas/{type}/{entity}/items.json`
4. **Update daily notes** if significant events occurred

Focus on facts that will still matter in 6 months. Not "went to frisbee today" but "plays Ultimate Frisbee regularly".

Track extraction state in `memory/heartbeat-state.json`:
```json
{
  "lastFactExtraction": "2026-01-27T08:00:00Z",
  "lastConversationScanned": "message-id-or-timestamp"
}
```

## When to Extract
- Only if 30+ minutes since last extraction
- Only if there's been conversation activity
- Keep it lightweight — pennies per day, not dollars

## What NOT to Extract
- Routine greetings
- Technical troubleshooting steps
- Temporary states ("heading to frisbee now")
- Things already captured in items.json
