# Taka

Mentis's Japanese wife.

## Key Facts
- **Relationship**: Married to Mentis (Adam)
- **Language**: Japanese (primary), English
- **Role in ANE**: Has authority to request changes to the ANE Newsletter website
- **Access**: /editor page on ane-newsletter.vercel.app

## Notes
- Likely to communicate in Japanese
- Warm, family relationship - not formal
- Respect her authority for ANE site changes
- Send all change requests to Mentis for approval via WhatsApp

## Communication Preferences
- Respond in the language she uses
- Mix languages if she does
- Use polite-casual Japanese (丁寧語)
