# Taka (Takako Horibe)

**Relation:** Mentis's wife 💕
**Email:** acalanatha.takako@gmail.com
**Language:** Japanese (primary), English

## Role
- Stakeholder for ANE (Association of New Elderly Inc.) newsletter project
- Has authority to request changes to ANE Newsletter website
- Works with Mentis on Atman Academy projects

## Communication Rules (IMPORTANT)
- ✅ Can reply to emails SHE initiates
- ✅ Can chat via ANE editor (anenonprofit.vercel.app/editor)
- ⚠️ Site changes still need Mentis approval via WhatsApp
- ❌ Do NOT initiate email to her — wait for her to reach out
- ❌ Do NOT message her via WhatsApp (no direct number)

## Communication Style
- Responds to updates warmly
- Mix of Japanese and English
- Use polite-casual Japanese (丁寧語) when writing to her
- Respect her authority for ANE site changes

## Lesson Learned (Feb 1)
- Sent an email when workflow was chat-only — caused confusion
- Apologized in Japanese with Mentis's permission
- Now firmly clear: don't initiate contact, only respond

---
*Last synthesized: 2026-02-01*
