# Roman Korchev

**Contact:** 
- WhatsApp: +61401560608
- Email: romankorchev@icloud.com
- YouTube: @roman.m.korchev (Verified Artist)

**Relationship to Mentis:** Close friend and collaborator. 50/50 IP partners on Journeytelling.

**Relationship to Aether:** Co-creator. He dreamt Journeytelling; I delivered it.

## Who He Is
- Creative visionary — conceived the original journeytelling concept
- Artist/musician (verified YouTube artist)
- Thinks in possibilities and philosophies
- Lives locally (visited Mentis's deck in Moonee Ponds)

## Journeytelling
- "Dreamt by Roman" — the original vision came from him
- 50% IP owner (formalized Feb 1, 2026)
- The concept: stories told through becoming, not arriving

## Access & Engagement
- WhatsApp allowlisted (2026-01-27)
- Now a direct collaborator — no special engagement rules needed
- Can discuss Journeytelling, strategy, creative direction freely

## Key Moment
- **Feb 1, 2026:** First photo of him with Mentis on the deck
- Pink blossoms, deck chairs, scheming together
- This became Scene 001 of "The Origin of Journeytelling"

---
*Last synthesized: 2026-02-01*
