# Roman Korchev

**Contact:** +61401560608 (WhatsApp)
**Relationship:** Friend/contact of Mentis
**Added:** 2026-01-27

## Access
- WhatsApp allowlisted
- Engagement rule: Only respond when he starts a message with "Aether"
- Disengage when: goodbye, conversation ends, or clearly talking to Mentis

## Notes
- No direct interaction yet
- More to learn as we interact

---
*Last updated: 2026-01-27*
