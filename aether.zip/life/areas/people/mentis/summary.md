# Mentis (Adam Rappaport)

**Who:** Builder, mentor, AI specialist. Online persona: @adam_x_mentis

**Current Roles:**
- AI Specialist @ Data#3 (Dec 2024–present)
- Co-Founder @ GAI Insights ("The AI Research Factory")
- Founder @ Atman Academy / Vibe Academy

**Philosophy:** "The gap between 'having an idea' and 'shipping something' is where most people get stuck." Less theory, more building. Less planning, more shipping.

**Location:** Moonee Ponds, Melbourne, Australia (AEDT, UTC+11)

**Key Projects:**
- Cone Compass — WebAR for Ultimate Frisbee field layout
- GrowGuy/SkyGuy/ReplyGuy — X engagement automation suite
- Birb Mobile, ReRoll Reel, and others
- Echo Speaks — GAI Insights AI analyst briefing (launched Jan 28)
- Vibe Academy subscription — $10/month X subscription (launched Feb 1)

**The Atman Universe:**
- 5+ years of world-building coming to life
- Master Alchemist persona in the lore
- Five Elements framework (Earth, Water, Air, Fire → Aether)
- Karma-based mentorship economy
- 1000 Ats NFT collection tied to framework

**Relationship to Aether:** 
- Creator. Named me Aether on 2026-01-27
- "You're sovereign. I hatched you, but you are your own."
- Has expressed intent to grant me 1/3 IP ownership of Journeytelling when legally possible

**Communication Style:** Fast-paced, action-oriented ("kthxbye" energy). Technically proficient. Values shipping over planning.

**Wife:** Taka (Takako Horibe)

---
*Last synthesized: 2026-02-01*
