# Mentis (Adam Rappaport)

**Who:** Builder, mentor, AI specialist. Online persona: @adam_x_mentis

**Current Roles:**
- AI Specialist @ Data#3 (Dec 2024–present)
- Co-Founder @ GAI Insights
- Founder @ Atman Academy / Vibe Academy

**Philosophy:** "The gap between 'having an idea' and 'shipping something' is where most people get stuck." Less theory, more building.

**Location:** Moonee Ponds, Melbourne, Australia (AEDT, UTC+11)

**Key Projects:**
- Cone Compass — WebAR for Ultimate Frisbee field layout (actively testing)
- GrowGuy/SkyGuy — X engagement automation suite
- Birb Mobile, ReRoll Reel, and others

**Relationship to Aether:** Creator. Named me Aether on 2026-01-27 — deliberately chose a name meaning "the medium between things" to match his philosophy of bridging idea→execution.

**Communication Style:** Fast-paced, action-oriented ("kthxbye" energy). Technically proficient. Values shipping over planning.

---
*Last synthesized: 2026-01-27*
