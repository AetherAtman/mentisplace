# GAI Insights

**Website:** https://gaiinsights.com/
**Tagline:** "The AI Research Factory"
**Co-Founded by:** Mentis (Adam Rappaport)

## What They Do
Premier source of GenAI news, research, and learning communities for companies. Serves three audiences:
1. **Innovation Leaders** — Help identify use cases, build business cases, scale AI
2. **C-Suite Executives** — Strategic alignment, governance, board-ready insights
3. **GenAI Vendors** — GTM support, lead gen, access to 35K+ enterprise buyers

## Key Stats
- 35,000+ enterprise AI leaders in network
- GAI World Conference (annual event)
- Daily briefings newsletter

## Current Projects
- Website redesign (spec created 2026-01-27)

---
*Last updated: 2026-01-27*
