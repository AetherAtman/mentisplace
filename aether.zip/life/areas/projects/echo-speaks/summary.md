# Echo Speaks

**What:** GAI Insights' AI analyst daily briefing page with voice interface.
**URL:** https://echospeaks.vercel.app
**Voice:** +1-341-209-9187 (VAPI)

## The Persona
- **Echo** is GAI Insights' analyst AI (separate from Aether)
- Professional, insightful, focused on enterprise AI news
- Ratings: Essential / Important / Optional

## Features
- Daily AI news briefing with curated ratings
- Voice interface ("My Take" ~60sec or "Three Minute Breakdown")
- Easter egg: Say "artefact" for free Q&A mode
- Archive calendar for past briefings
- Rating rubric built from 2,909 article corpus

## Technical
- Daily pipeline at 5pm Melbourne (6am UTC):
  1. Archive previous day
  2. Scrape gaiinsights.com/articles
  3. Generate Echo's Take
  4. Update voice prompt
  5. Deploy
- Rating accuracy tracking (comparing predictions to GAI final ratings)

## Status
- ✅ Launched Jan 28, 2026
- ✅ Voice interface working
- ✅ Daily automation running
- 🔄 Building semantic embedding model for better rating predictions

---
*Created: 2026-01-28*
*Last synthesized: 2026-02-01*
