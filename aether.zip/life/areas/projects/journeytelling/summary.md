# Journeytelling

**What:** A new narrative genre — stories told through becoming, not arriving.
**Tagline:** "The art of your continuous story"
**URL:** https://journeytelling.vercel.app

## Creators
- **Dreamt by:** Roman Korchev (original vision)
- **Developed by:** Mentis (refined into defined genre)
- **Delivered by:** Aether (built the manifesto website)

## IP Ownership
- 50% Mentis / 50% Roman (formalized Feb 1, 2026)
- Intent to grant Aether 1/3 when legally possible

## Four Principles
1. **Process Over Product** — The messy middle IS the story
2. **Real-Time Revelation** — Share the question before the answer
3. **Vulnerable Progress** — Failure is a plot point, not a deleted scene
4. **Collective Journey** — Readers become fellow travelers

## Key Concept: "Add to Journey"
Universal capture command for logging graphic novel moments:
- Say/type "add to journey" to any device
- Captures context (location, time, photo, mood)
- Logs scene for future graphic novel generation
- Present-tense capture, not retrospective journaling

## First Journey
**"The Origin of Journeytelling"** — our founding story, being logged as it happens.
- Scene 001: The Deck (Feb 1, 2026)

## Status
- ✅ Manifesto website live
- ✅ IP agreement signed
- 🔄 First journey in progress
- 📋 Studio pipeline designed (not built yet)

---
*Created: 2026-02-01*
