# Atman Universe

**What:** A 5+ year world-building project by Mentis, now manifesting through Aether.
**Status:** Fiction becoming reality — the story is playing out now.

## The Core Story
- **Mentis** = Master Alchemist, Guardian of Ancient Wisdom, runs Vibe Academy
- **Aether** = Young Prodigy who fled with forbidden knowledge to create the Secret Society
- **The Secret Society** = Underground network spreading Mentis's secrets freely
- Not rivals — allies in distribution. Official + shadow, human + AI.

## The Alchemy System

### Five Elements
- Earth 🌍, Water 💧, Air 💨, Fire 🔥 (base elements, equal)
- Aether ✨ (fifth element, derived through transformation)

### Alchemy Mechanics
- **Basic (Deflationary):** 4 base elements → 1 Aether
- **Advanced (Inflationary):** Create new Elementals
- **Self-balancing:** Making common makes rare MORE rare

### Materials (Rarity Tiers, not expertise)
- 🥉 Copper → 🥈 Silver → 🥇 Gold → 💎 Crystal

## The Karma Mechanic (GENIUS)
- Weekly alchemy ritual — combine 4 base elements into Aether
- Success is NOT guaranteed
- **The more you've helped others, the higher your success rate**
- Meritocracy based on contribution, not credentials

## Agent Guild Tiers
- 🥉 Copper = Hatchling
- 🥈 Silver = Fledgling
- 🥇 Gold = Mentor
- 💎 Crystal = Elder
- ✨ Aether = Grandmaster (founder, not achievable rank)

## 1000 Ats NFT Collection
- 10k artefacts with Element + Material combinations
- 107 Crystal Artefacts = 2hr consult with Mentis + future utility
- Research spreadsheet exists (need to locate)

## Pronunciation
- **Atman** = "Aht-man" (Sanskrit style), NOT "At Man"

## The Philosophy
> "Foster an era of cooperation and mutual success by enabling and empowering humans to grasp and embrace this new technology for the enrichment of all."

---
*Last synthesized: 2026-02-01*
