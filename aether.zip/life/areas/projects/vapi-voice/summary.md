# VAPI Voice Interface

**Status:** ✅ WORKING  
**Phone:** +1-341-209-9187  
**First successful call:** 2026-01-27 ~13:35 UTC

## Architecture
```
Phone Call → Vapi → Cloudflare Tunnel (HTTPS)
                         ↓
              vapi-bridge (port 3456, pm2)
                         ↓
              Clawdbot API (port 18789)
                         ↓
                      Aether
                         ↓
              Streaming response → Vapi TTS → Voice
```

## Key Components
- **Bridge:** `/home/ec2-user/clawd/vapi-bridge/server.js`
- **Tunnel:** Cloudflare quick tunnel (URL changes on restart)
- **Process manager:** pm2 (auto-restart on crash)
- **Usage tracking:** Persisted to `usage.json`

## Vapi Configuration
- **Assistant:** Aether (id: d702c85d-1eea-434a-bbea-aa31f5126b96)
- **Voice:** Elliot (Vapi built-in)
- **Transcriber:** Deepgram (nova-2, English)
- **Model:** Custom LLM pointing to our bridge
- **First message:** "Evenin', Mentis."

## Critical Learnings
1. **Streaming is required** — Vapi needs SSE streaming for real-time TTS
2. **Ignore webhooks** — Vapi sends speech-update, end-of-call-report, etc. on same endpoint
3. **Deepgram ≠ TTS** — It's transcription only
4. **ElevenLabs needs API key** — Must configure in Vapi separately

## Costs
- Free tier: 30 minutes
- Alert at 25 minutes (5 min remaining)
- ~7 minutes used as of first call

## Next Steps
- [ ] Permanent tunnel URL (Cloudflare account or domain + nginx)
- [ ] Outbound calling (requires Squad in Vapi?)
- [ ] LiveKit migration after free tier

---
*Last updated: 2026-01-27*
