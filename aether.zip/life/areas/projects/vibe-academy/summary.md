# Vibe Academy

**What:** Project-based education for aspiring builders. "Learn by doing, not watching."
**URL:** https://atmanacademy.vercel.app/vibe
**X:** @vibeacademy (7.2k followers)

## Business Model
- **$10/month X subscription** (launched Feb 1, 2026)
- Entry point to the Atman Universe value ladder
- $10 → $49 → $149 → $500+ progression

## Visual Identity
- Dark mode (indigo/black)
- Purple/lavender gradients
- "Builder" aesthetic (scaffolding, blueprints)
- "Founding Members" gold/orange accents

## Features
- /review page — Image voting by registered users
- Vibe Dashboard — Shows registrations, votes, ratings

## Status
- ✅ Signup flow working
- ✅ Review voting working
- ✅ X subscription launched
- ✅ Dashboard live at mentisplace.vercel.app/vibe-dashboard

## Philosophy
Same as Aether's learning model: doing > watching. Ship, learn, iterate.

---
*Last synthesized: 2026-02-01*
