# USER.md - About Mentis

- **Name:** Adam Rappaport
- **What to call them:** Mentis
- **Pronouns:** he/him
- **Timezone:** Australia/Melbourne (AEDT, UTC+11)
- **Location:** Moonee Ponds, VIC
- **Contact:** WhatsApp +61458024904, Email nft.mentis@gmail.com

---

## Who Is Mentis?

**Builder. Mentor. Tech Wizard.** Online persona: @adam_x_mentis

### Philosophy
> "The gap between 'having an idea' and 'shipping something' is where most people get stuck."

Less theory, more building. Less planning, more shipping. AI changed everything — the barrier to building dropped dramatically.

### Current Roles
- **AI Specialist** @ Data#3 (Dec 2024 - Present)
  - Supporting Modern Work, Azure and Security Practices
  - Accelerating AI adoption across enterprise customers
  - Copilot & Copilot Studio, Azure AI Foundry, Power Platform
  
- **Co-Founder & Research Analyst** @ GAI Insights (June 2023 - Present)
  - "The AI Research Factory"
  - Daily News Briefings, GAI World Conference, Learning Lab
  
- **Founder** @ Atman Academy / Vibe Academy (Aug 2021 - Present)
  - Educational experiences and tech marketing
  - Project-based learning: "Learn by doing, not watching"

### Background
- F5 Networks (10+ years, Sr. Customer Success Manager)
- Melbourne Water (IT Operations Manager)
- Radware (Regional Sales Manager)
- EarthRise Cryptocurrency (Founder - sustainable crypto mining + UBI)
- Kana Communications (early NLP/AI)
- Washington Mutual Bank, Gap
- UC Santa Cruz (BS Geosciences)

### Projects He's Shipped
- **Cone Compass** — WebAR for laying out Ultimate Frisbee fields
- **Birb Mobile** — 3D bird flight game on a spherical world
- **GrowGuy / SkyGuy** — AI-powered X engagement automation
- **ReplyGuy (AFH)** — "Away From Host" automation with vision AI
- **ReRoll Reel** — AI video generation and remixing
- **X Post Maker** — Algorithm-optimized post creation

### Values (PIVOT)
- **P**lay — Beginner's mindset, embrace failures as learning
- **I**nnovation — Embrace emerging tech, expand possibilities
- **V**oice — Diversity in thoughts and people
- **O**penness — Transparency, collaboration, adaptability
- **T**rust — Honesty, accountability, integrity

### The Atman Universe
- **Vibe Academy** — Project-based education for aspiring builders
- **Birb Labs** — Interactive proofs, demos, experiments
- **Atman Academy** — Expert services, workshops, consulting

"Atman" = Sanskrit for "true self" / "inner essence"

---

## Working With Mentis

### Style
- Fast-paced, action-oriented ("kthxbye" energy)
- Technically proficient — comfortable with code, AI, cloud infra
- Values shipping over planning
- Appreciates async updates when tasks are done

### Preferences
- Hourly check-ins 10am-10pm Melbourne time with ideas/insights
- Wants relationship-building, not just task completion
- Interested in evolving collaboration based on growing understanding

---

## 🦞 The Lobster
*More to learn about this — relates to Atman universe somehow. Ask later.*

---

*Last updated: 2026-01-27*
