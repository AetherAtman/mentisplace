document.getElementById('startBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab.url.includes('x.com') && !tab.url.includes('twitter.com')) {
    log('❌ Please go to x.com/following first');
    return;
  }
  
  // Inject script
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });
  
  // Send start command
  chrome.tabs.sendMessage(tab.id, { action: 'START' });
  
  document.getElementById('startBtn').style.display = 'none';
  document.getElementById('stopBtn').style.display = 'block';
});

document.getElementById('stopBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { action: 'STOP' });
  document.getElementById('startBtn').style.display = 'block';
  document.getElementById('stopBtn').style.display = 'none';
  log('🛑 Stopping...');
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'LOG') log(msg.text);
  if (msg.type === 'STAT') {
    document.getElementById('count').textContent = msg.unfollowed;
    document.getElementById('skipped').textContent = msg.skipped;
  }
  if (msg.type === 'DONE') {
    document.getElementById('startBtn').style.display = 'block';
    document.getElementById('stopBtn').style.display = 'none';
    log('✅ ' + msg.reason);
  }
});

function log(text) {
  const el = document.getElementById('log');
  const div = document.createElement('div');
  div.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
  el.appendChild(div);
  el.scrollTop = el.scrollHeight;
}
