// VibeCleaner Content Script
// 2026-01-29 - Aether

const ALLOWLIST = [
  'adam_x_mentis', 'vibeacademy', 'aether_ai', // Add specific friends here
  'elonmusk' // Just in case
];

const MAX_SESSION_UNFOLLOWS = 200;
let state = {
  running: false,
  unfollowed: 0,
  skipped: 0
};

// Listen for popup commands
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'START') {
    if (state.running) return;
    state.running = true;
    startCleaning();
  }
  if (msg.action === 'STOP') {
    state.running = false;
    log('Stopped by user');
  }
});

function log(text) {
  console.log(`[VibeCleaner] ${text}`);
  chrome.runtime.sendMessage({ type: 'LOG', text });
}

function updateStats() {
  chrome.runtime.sendMessage({ 
    type: 'STAT', 
    unfollowed: state.unfollowed, 
    skipped: state.skipped 
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function randomDelay(min = 2000, max = 5000) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

// Check if user is verified (Blue, Gold, Grey)
function isVerified(userCell) {
  // Look for the specific SVG icon usually associated with verification
  // X uses aria-label="Verified account" or "Verified Organization" often
  const verifiedIcon = userCell.querySelector('svg[aria-label="Verified account"], svg[data-testid="icon-verified"]');
  // Also check for gold/grey checks which might have specific paths or colors, 
  // but usually they all have the data-testid="icon-verified"
  return !!verifiedIcon;
}

function getHandle(userCell) {
  const link = userCell.querySelector('a[href^="/"][role="link"]');
  if (!link) return null;
  const handle = link.getAttribute('href').replace('/', '');
  return handle;
}

async function startCleaning() {
  log('Starting cleaning cycle...');
  
  while (state.running) {
    if (state.unfollowed >= MAX_SESSION_UNFOLLOWS) {
      state.running = false;
      chrome.runtime.sendMessage({ type: 'DONE', reason: 'Session limit reached' });
      return;
    }

    // Find all user cells
    const cells = Array.from(document.querySelectorAll('[data-testid="UserCell"]'));
    
    // Process cells
    let processedAny = false;
    
    for (const cell of cells) {
      if (!state.running) break;
      
      // Skip if already processed (mark them)
      if (cell.dataset.vcProcessed) continue;
      
      // Check if "Following" button exists (ensure we are actually following them)
      // The button usually says "Following" and has specific classes
      const followBtn = cell.querySelector('[data-testid$="-unfollow"]');
      if (!followBtn) {
        cell.dataset.vcProcessed = "true"; // Not following or different state
        continue;
      }

      processedAny = true;
      const handle = getHandle(cell);
      const verified = isVerified(cell);
      
      log(`Checking @${handle}... Verified: ${verified}`);

      // CHECK: Allowlist
      if (ALLOWLIST.includes(handle)) {
        log(`🛡️ Skipping @${handle} (Allowlist)`);
        state.skipped++;
        cell.dataset.vcProcessed = "true";
        updateStats();
        continue;
      }

      // CHECK: Verified
      if (verified) {
        log(`✅ Skipping @${handle} (Verified)`);
        state.skipped++;
        cell.dataset.vcProcessed = "true";
        updateStats();
        continue;
      }

      // ACTION: Unfollow
      log(`🗑️ Unfollowing @${handle}...`);
      
      // 1. Click "Following" (opens modal)
      followBtn.click();
      await sleep(1000); // Wait for modal
      
      // 2. Click "Unfollow" in confirmation modal
      const confirmBtn = document.querySelector('[data-testid="confirmationSheetConfirm"]');
      if (confirmBtn) {
        confirmBtn.click();
        state.unfollowed++;
        updateStats();
        cell.dataset.vcProcessed = "true";
        
        // Safety Pause
        const delay = randomDelay(2500, 5500);
        log(`Waiting ${delay}ms...`);
        await sleep(delay);
      } else {
        log('⚠️ Could not find confirmation button');
        // Close modal if stuck? usually clicking background works or Escape
        // minimal recovery: just mark processed and move on
        cell.dataset.vcProcessed = "true";
      }
    }

    if (!processedAny && state.running) {
      log('📉 Scrolling for more users...');
      window.scrollBy(0, window.innerHeight);
      await sleep(3000);
      
      // Check if we hit bottom
      // (Simplified logic for now)
    }
    
    await sleep(1000);
  }
}
